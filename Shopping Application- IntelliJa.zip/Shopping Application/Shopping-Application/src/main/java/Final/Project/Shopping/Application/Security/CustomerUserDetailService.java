package Final.Project.Shopping.Application.Security;


import Final.Project.Shopping.Application.Entities.RegisterationRecord;
import Final.Project.Shopping.Application.Repositories.RegisterationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
@Service
public class CustomerUserDetailService implements UserDetailsService  {

    @Autowired
    private RegisterationRepo registerationRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        RegisterationRecord user = this.registerationRepo.findByEmail(username);
        return user;
    }
}

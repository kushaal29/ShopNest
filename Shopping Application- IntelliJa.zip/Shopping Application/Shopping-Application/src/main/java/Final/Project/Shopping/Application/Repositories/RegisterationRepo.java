package Final.Project.Shopping.Application.Repositories;

import Final.Project.Shopping.Application.Entities.RegisterationRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegisterationRepo extends JpaRepository<RegisterationRecord, Integer> {

    RegisterationRecord findByEmail(String email);
}

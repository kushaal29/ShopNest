package Final.Project.Shopping.Application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopNest {

	public static void main(String[] args) {
		SpringApplication.run(ShopNest.class, args);
	}

}

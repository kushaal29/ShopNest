import { Component } from '@angular/core';
import { UserloginService } from '../../service/userlogin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})

export class LoginComponent {
  userData= {
    email:'',
    password:''
    
  }
  image= 'app/apges/create-user/Bground.jpg';

  

  

  constructor(private loginService :UserloginService, private router: Router){}

  
  formSubmit()
  {

    console.log("Inside Method");
    this.loginService.loginMethod(this.userData).subscribe((data:any)=>{
      this.router.navigateByUrl('/welcome')
      
    })
    }

    signup(){
      this.router.navigateByUrl('/create')
    }

   }


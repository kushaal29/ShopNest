package Final.Project.Shopping.Application.Service;


import Final.Project.Shopping.Application.Entities.AddProduct;
import Final.Project.Shopping.Application.Repositories.AddProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AddProductService {
    @Autowired
    private AddProductRepo addProductRepo;

    public AddProduct addProduct(AddProduct saveData)
    {
        AddProduct productAdd= new AddProduct();
        productAdd.setProductName(saveData.getProductName());
        productAdd.setPrice(saveData.getPrice());
        return this.addProductRepo.save(productAdd);
    }

    public AddProduct details (AddProduct addProductName)
    {
        return this.addProductRepo.save(addProductName);
    }

    public AddProduct productById (int id)
    {
        return this.addProductRepo.findById(id).get();
    }

    public List<AddProduct> allproductRecord()
    {
        return this.addProductRepo.findAll();
    }


    public AddProduct userUpdation(int id, AddProduct productUpdate){
        AddProduct user = this.addProductRepo.findById(id).get();
        AddProduct updateProduct= new AddProduct();

        if(user.getProductName()!=null)
        {
            updateProduct.setCartId(id);
            updateProduct.setProductName(productUpdate.getProductName());
            updateProduct.setPrice(productUpdate.getPrice());

            this.addProductRepo.save(updateProduct);
        }
        else
        {
            System.out.println("Product with Cart ID: "+ id + " not found");
        }
        return updateProduct;
    }

    public int deleteProduct(int id)
    {
        this.addProductRepo.deleteById(id);
        return id;
    }

}

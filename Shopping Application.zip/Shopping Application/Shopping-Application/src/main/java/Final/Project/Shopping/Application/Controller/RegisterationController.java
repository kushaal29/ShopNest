package Final.Project.Shopping.Application.Controller;


import Final.Project.Shopping.Application.Entities.RegisterationRecord;
import Final.Project.Shopping.Application.Service.RegisterationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/shopNest")
@CrossOrigin("*")
public class RegisterationController {
    @Autowired
    private RegisterationService registerationService;


//Add Details of the User.//
    @PostMapping("/signUp")
    public RegisterationRecord addDetails(@RequestBody RegisterationRecord saveDetails)
    {
        return this.registerationService.addDetail(saveDetails);
    }

//Search User by Unique ID Assigned.//
    @GetMapping("/getbyId/{id}")
    public RegisterationRecord getbyId(@PathVariable Integer id)
    {
        return this.registerationService.userById(id);
    }

// Show All Data of the Existing Users in the App.//
    @GetMapping("/showAllData")
    public List<RegisterationRecord> userEntityList()
    {
        return this.registerationService.allUsersRecord();
    }

// Update record of the User.//
    @PutMapping("/update/{id}")
    public RegisterationRecord updateUserRecord(@PathVariable Integer id,@RequestBody RegisterationRecord schoolRecord)
    {
        return this.registerationService.userUpdation(id, schoolRecord);
    }

// Delete the record of the Existing User from the App.
    @DeleteMapping("/delete/{id}")
    public int deleteUsers(@PathVariable int id)
    {
        return this.registerationService.deleteUser(id);

    }

}

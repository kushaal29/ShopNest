package Final.Project.Shopping.Application.Repositories;

import Final.Project.Shopping.Application.Entities.AddProduct;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddProductRepo extends JpaRepository<AddProduct, Integer> {
}

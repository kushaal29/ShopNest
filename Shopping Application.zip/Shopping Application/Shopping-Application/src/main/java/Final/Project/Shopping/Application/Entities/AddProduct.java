package Final.Project.Shopping.Application.Entities;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name="Product List")
public class AddProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int cartId;

    @Column(name = "Product")
    private String productName;

    @Column(name = "Price")
    private String price;





}

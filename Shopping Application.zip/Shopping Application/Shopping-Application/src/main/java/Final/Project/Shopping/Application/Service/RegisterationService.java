package Final.Project.Shopping.Application.Service;


import Final.Project.Shopping.Application.Entities.RegisterationRecord;
import Final.Project.Shopping.Application.Repositories.RegisterationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegisterationService {
    @Autowired
    private RegisterationRepo registerationRepo;
    @Autowired
    private PasswordEncoder passwordEncoder;


//Get and Set details of New User to the Shopping Application.//

    public RegisterationRecord addDetail(RegisterationRecord saveData)
    {
        RegisterationRecord register= new RegisterationRecord();
        register.setFirstname(saveData.getFirstname());
        register.setLastname(saveData.getLastname());
        register.setPhone(saveData.getPhone());
        register.setEmail(saveData.getEmail());
        register.setPassword(this.passwordEncoder.encode(saveData.getPassword()));
        return this.registerationRepo.save(register);
    }

    public RegisterationRecord details (RegisterationRecord addRegisteration)
    {
        return this.registerationRepo.save(addRegisteration);
    }


// Search particular user by assigned Unique ID.//

    public RegisterationRecord userById (int id)
    {
        return this.registerationRepo.findById(id).get();
    }


// Get Full list of Users registered on the Application

    public List<RegisterationRecord> allUsersRecord()
    {
        return this.registerationRepo.findAll();
    }


// Update details of the Existing User on the App.//

    public RegisterationRecord userUpdation(int id, RegisterationRecord recordUpdate){
        RegisterationRecord user = this.registerationRepo.findById(id).get();
        RegisterationRecord updateUser= new RegisterationRecord();

        if(user.getFirstname()!=null)
        {
            updateUser.setId(id);
            updateUser.setFirstname(recordUpdate.getFirstname());
            updateUser.setLastname(recordUpdate.getLastname());
            updateUser.setPhone(recordUpdate.getPhone());
            updateUser.setEmail(recordUpdate.getEmail());
            updateUser.setPassword(this.passwordEncoder.encode(recordUpdate.getPassword()));

            this.registerationRepo.save(updateUser);
        }
        else
        {
            System.out.println("Customer with User ID: "+ id + " not found");
        }
        return updateUser;
    }


//Delete Existing User by Id.//

    public int deleteUser(int id)
    {
        this.registerationRepo.deleteById(id);
        return id;
    }


}

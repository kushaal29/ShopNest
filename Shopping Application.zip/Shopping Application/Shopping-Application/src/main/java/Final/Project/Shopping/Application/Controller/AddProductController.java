package Final.Project.Shopping.Application.Controller;


import Final.Project.Shopping.Application.Entities.AddProduct;
import Final.Project.Shopping.Application.Service.AddProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
@CrossOrigin("*")
public class AddProductController {
    @Autowired
    private AddProductService addProductService;


    @PostMapping("/addDetail")
    public AddProduct addDetails(@RequestBody AddProduct saveDetail)
    {
        return this.addProductService.addProduct(saveDetail);
    }

    @GetMapping("/getbyId/{id}")
    public AddProduct getbyId(@PathVariable Integer id)
    {
        return this.addProductService.productById(id);
    }

    @GetMapping("/showAllData")
    public List<AddProduct> userEntityList()
    {
        return this.addProductService.allproductRecord();
    }

    @PutMapping("/update/{id}")
    public AddProduct updateProductRecord(@PathVariable Integer id,@RequestBody AddProduct productRecord)
    {
        return this.addProductService.userUpdation(id, productRecord);
    }

    @DeleteMapping("/delete/{id}")
    public int deleteProducts(@PathVariable int id)
    {
        return this.addProductService.deleteProduct(id);

    }
}

package Final.Project.Shopping.Application.Repositories;

import Final.Project.Shopping.Application.Entities.AddToCart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepo  extends JpaRepository<AddToCart, Integer> {
}

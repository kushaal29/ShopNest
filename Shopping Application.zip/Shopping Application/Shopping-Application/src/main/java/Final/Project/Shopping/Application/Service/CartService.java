package Final.Project.Shopping.Application.Service;

import Final.Project.Shopping.Application.Entities.AddProduct;
import Final.Project.Shopping.Application.Entities.AddToCart;
import Final.Project.Shopping.Application.Entities.RegisterationRecord;
import Final.Project.Shopping.Application.Repositories.AddProductRepo;
import Final.Project.Shopping.Application.Repositories.CartRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {
    @Autowired
    private CartRepo cartRepo;



    public AddToCart addCart(AddToCart saveData)
    {
        AddToCart productAdd= new AddToCart();
        productAdd.setProductName(saveData.getProductName());
        productAdd.setPrice(saveData.getPrice());
        return this.cartRepo.save(productAdd);
    }

    public AddToCart details (AddToCart addProductName)
    {
        return this.cartRepo.save(addProductName);
    }

    public List<AddToCart> allCartRecord()
    {
        return this.cartRepo.findAll();
    }


}

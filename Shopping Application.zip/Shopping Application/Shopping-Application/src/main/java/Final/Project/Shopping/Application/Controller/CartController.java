package Final.Project.Shopping.Application.Controller;


import Final.Project.Shopping.Application.Entities.AddProduct;
import Final.Project.Shopping.Application.Entities.AddToCart;
import Final.Project.Shopping.Application.Entities.RegisterationRecord;
import Final.Project.Shopping.Application.Service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
@CrossOrigin("*")
public class CartController {

    @Autowired
    private CartService cartService;


    @PostMapping("/addDetail")
    public AddToCart addDetails(@RequestBody AddToCart saveDetail)
    {
        return this.cartService.addCart(saveDetail);
    }

    @GetMapping("/showAllData")
    public List<AddToCart> userEntityList()
    {
        return this.cartService.allCartRecord();
    }


}

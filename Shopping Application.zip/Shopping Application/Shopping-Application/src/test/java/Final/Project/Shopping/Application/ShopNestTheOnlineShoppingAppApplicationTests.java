package Final.Project.Shopping.Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopNestTheOnlineShoppingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
